var towerimg,tower;
var doorimg,door,doorsGroup;
var climberimg,climber,climbersGroup;
var ghostimg,ghost;
var invisibleBlock,invisibleBlockGroup
var gameState="play";
function preload(){
  
    towerimg=loadImage("tower.png");
    doorimg=loadImage("door.png");
    climberimg=loadImage("climber.png");
    ghostimg=loadImage("ghost.png");
  }


function setup(){
    createCanvas(600,600);
    tower=createSprite(300,300);
    tower.addImage("tower",towerimg)
    tower.velocityY=1;
    //making groups
    doorsGroup=new Group();
    climbersGroup=new Group();
    invisibleBlockGroup=new Group();
    ghost=createSprite(200,200,50,50);
    ghost.scale=0.3;
    ghost.addImage("ghost",ghostimg);
}


function draw(){
    background(0);
   if(gameState==="play"){
   if(keyDown("left_arrow"))
   ghost.x= ghost.x-3; 
   if(keyDown("right_arrow")) 
   ghost.x= ghost.x+3; 
   if(keyDown("space")){
   ghost.velocityY=-2  
    }
   ghost.velocityY=ghost.velocityY+0.001;  
   if(tower.y>400)  {
    tower.y=300; 
   }
}
spawnDoors();
if(climbersGroup.isTouching(ghost)){
   ghost.velocityY=0;
}
if(invisibleBlockGroup.isTouching(ghost) || ghost.y>600){
   ghost.destroy();
   gameState="end";
}
drawSprites();
}    
function spawnDoors(){
    if(frameCount%240===0){
   var door=createSprite(200,-50);
   var climber=createSprite(200,10);   
   var invisibleBlock=createSprite(200,50); 
      invisibleBlock.width=climber.width;
      invisibleBlock.height=2;
      door.x=math.round(random(120,400));
      climber.x=door.x;
      invisibleBlock.x=door.x;
      door.addImage(doorimg)
  }
     
     
     }
                     
                     
                     
                     
        
  










